/*jslint node: true */
'use strict';

/**
 * Visual Builder application build script.
 * For details about the application build and Visual Builder-specific grunt tasks
 * provided by the grunt-vb-build npm dependency, please refer to
 * https://www.oracle.com/pls/topic/lookup?ctx=en/cloud/paas/app-builder-cloud&id=visual-application-build
 */
module.exports = (grunt) => {
  grunt.initConfig({
    'vb-require-bundle': {
      "dcs": {
        "options": {
          "transpile": true,
          "minify": true,
          "bundles": {
            "appbundle": {
              "modules": {
                "find": [
                  "app-flow.json",
                  "app-flow.js",
                  "^build",
                  "!^build/components/oj-odcs/.*/fontawesome",
                  "^flows/",
                  "^pages/",
                  "^resources/css",
                  "^services/",
                ]
              }
            }
          }
        }
      }
    }
  }),
  require('load-grunt-tasks')(grunt);
};
