define([
  'ojs/ojcore'
], function(
  oj
) {
  'use strict';

  var PageModule = function PageModule() {
  };

  // Scroll to the top of the document
  PageModule.prototype.scrollTop = function() {
    document.body.scrollTop = 0; // For Safari
    document.documentElement.scrollTop = 0; // For Chrome, Firefox, IE and Opera
  };

  /**
   * Opens the user menu 
   *  
   * @param {String} event The event used to invoke the user menu opening
   */
  PageModule.prototype.launchMenu = function (event) {
     document.getElementById("account_menu").open(event);
  };


  return PageModule;
});