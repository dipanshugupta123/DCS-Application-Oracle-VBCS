/* Oracle Digital Customer Service Template 21D 3.15.0: releases/21.10.1 b0837da2 2022-10-19T20:16:46.461Z */
define([
  'knockout',
  'ojs/ojcore',
  'oj-odcs/application-common/ApplicationCommon',
  'oj-odcs/application-common/IdcsUtils',
  'oj-odcs/application-common/OdcsSecurityProvider',
  'oj-odcs/knowledge-common/KnowledgeCommon',
  'oj-odcs/visual-navigator-common/VisualNavigatorCommon',
  'vb/helpers/rest',
  'vb/helpers/navigate',
  'oj-odcs/common/Polyfill',
  'css!oj-odcs/fontawesome/css/all.css'
], function(
  ko,
  oj,
  ApplicationCommon,
  IdcsUtils,
  OdcsSecurityProvider,
  KnowledgeCommon,
  VisualNavigatorCommon,
  Rest,
  Navigate
) {
  'use strict';

  /**
   * This application module is used to make calls to functions
   * contained in the oj-odcs extensions pack modules, such as
   * application-common and knowledge-common, which provide common
   * utility used by the application.
   * @module AppModule
   */

  /** @constructor */
  var AppModule = function AppModule(context) {
    //The locale that JET is using
    this.jetLocale = oj.Config.getLocale();

    // Enable event based navigation to the custom sign-in page
    if (context) {
      OdcsSecurityProvider.setEventHelper(context.getEventHelper());
    }
  };

  /**
   * Function to do nothing called by NullAction
   */
  AppModule.prototype.doNothing = function() {};

  /**
   * Function to reload the application
   */
  AppModule.prototype.reload = function(force) {
    window.location.reload(force);
  };

  /**
   * Function to store the selected locale in browser storage
   *
   * @param {string} selectedLocale selected value from the locale picker
   */
  AppModule.prototype.setAppLocale = function(selectedLocale) {
    if (selectedLocale) {
      window.localStorage.setItem('odcs-reference-implementation.locale', selectedLocale);
    }
  };

  /**
   * Function to return the locale name of the current language
   *
   * @param {string} localeList Array of enabled locales
   * @return {string} name of the current locale
   */
  AppModule.prototype.readableLocale = function(localeList) {
    return ApplicationCommon.readableLocale(localeList, this.jetLocale);
  };

  /**
   * Returns the URL for the application homepage from the value passed in from $application.path
   * that contains <app_url>/version_xxx for staged and live apps
   *
   * @param {string} applicationPath The value in $application.path
   * @return {string} string with the parsed URL
   */
  AppModule.prototype.getAppUrl = function(applicationPath) {
    return ApplicationCommon.getAppUrl(applicationPath);
  };

  /**
   * Returns the name prior to the first space found in a username.
   * ie the first name.
   *
   * @param {String} user The full username.
   * @return {string} The string representing the first name of the user.
   */
  AppModule.prototype.getFirstName = function(user) {
    return ApplicationCommon.getFirstName(user);
  };

  /**
   * Returns the name after to the first space found in a username.
   * ie the last name, or names.
   *
   * @param {String} user The full username.
   * @return {string} The string representing the first name of the user.
   */
  AppModule.prototype.getLastName = function(user) {
    return ApplicationCommon.getLastName(user);
  };

  /**
   * Formats the passed in date object. If a format is passed into the function
   * it is used otherwise a default format is used.
   *
   * @param {type} dateTimeValue The date value to format
   * @param {type} format An optional date time format override
   * @param {boolean} relative A boolean used to generate relative date/time (e.g. 2 days ago, 3 weeks ago)
   * @param {type} separator An optional character to separate date and time strings (e.g. ' | ' to enable 'date | time')
   *
   * @return {string} The string representing the date in the format requested.
   */
  AppModule.prototype.formatDate = function(dateTimeValue, format, relative,
    separator) {
    return ApplicationCommon.formatDate(dateTimeValue, format, relative,
      separator);
  };

  /**
   * Formats the passed in date object relatively. If a format is passed into the function
   * it is used otherwise a default format with relativeField as 'day' is used.
   * In addition to the regular options supported on the JET dateTime converter,
   * the function also supports the following options:
   * relativeField: allowed values are day, week, month, year
   * If relativeField is 'day', then you may see the words
   * "today", "tomorrow" in the Schedule For field
   * If relativeField is 'week", you may see "this Week" or "next week", etc.
   * @param {(Object|string)} dateTimeValue The date value to format
   * @param {Object} formatOptions An Object literal that is used to pass in the intended relative date format
   * @return {string} The string representing the date in the relative format as requested.
   */
  AppModule.prototype.formatRelativeDate = function(dateTimeValue,
    formatOptions) {
    return ApplicationCommon.formatRelativeDate(dateTimeValue,
      formatOptions);
  };

  /**
   * Returns the LOV meaning for a given key.
   *
   * @param {string} key The key to lookup.
   * @param {type} lovs The lov object with an items attribute containing the array of key meaning pairs.
   * @return {string} The lov looked up meaning for the key passed in.
   */
  AppModule.prototype.getLOVMeaningValue = function(key, lovs) {
    return ApplicationCommon.getLOVMeaningValue(key, lovs);
  };

  /**
   * Validates all oj-validation-groups in the specified element or the whole
   * document if no element is supplied.
   *
   * @param {HTMLElement} root optional HTML element to validate the
   *                           oj-validation-group children of; the whole
   *                           document will be used otherwise.
   * @return {boolean} true if all oj-validation-groups are valid, false otherwise
   */
  AppModule.prototype.isValidForSubmit = function(root) {
    return ApplicationCommon.isValidForSubmit(root);
  };

  /**
   * Return a computed observable to ensure labels in an oj-form-layout are
   * positioned appropriately for the screen size. The returned observable can be
   * used as the label-edged attribute of the oj-form-layout.
   * <oj-form-layout id="layout" label-edge="[[ $application.functions.labelEdge() ]]">.
   *
   * @return {Observable} observable that returns start or top depending on screen size
   */
  AppModule.prototype.formLabelEdge = function() {
    return ApplicationCommon.formLabelEdge();
  };

  /**
   * Formats a number to the Intl default.
   *
   * @param {type} numberValue
   * @return {String} The formatted number as a string
   */
  AppModule.prototype.formatNumber = function(numberValue) {
    return ApplicationCommon.formatNumber(numberValue);
  };

  /**
   * Gets a string from the request response to display as
   * an end user message for a given error object. If the details
   * are not found, and the status is provided that is returned.
   * If the optional serviceUnavailableMessage is provided and there
   * is a status indicating a 500 error the passed in message is returned,
   * finally if no error object is passed a generic error message is
   * returned.
   *
   * @param {type} errorObj The error object
   * @param {String} serviceUnavailableMessage The optional message to display
   * when no error details are available and the status is a 500 error.
   * @param {String} defaultMsgIfNoDetails The optional message to display
   * when error details is empty
   * @param {String} defaultErrorMsg The optional message to display
   * when none of the cases match and error structure is unexpected.
   * @return {String} String stating the error status.
   */
  AppModule.prototype.getErrorDetail = function(errorObj,
    serviceUnavailableMessage, defaultMsgIfNoDetails, defaultErrorMsg) {
    return ApplicationCommon.getErrorDetail(errorObj,
      serviceUnavailableMessage, defaultMsgIfNoDetails, defaultErrorMsg
    );
  };

  /**
   * Builds the filter string into the configuration url,
   * based on the options passed in for the User Registrations table filter.
   *
   * @param {Object} configuration The Service Data Provider configuration object
   * @param {Object} options The Service Data Provider configuration object
   * @return {Object} The updated Service Data Provider configuration object.
   */
  AppModule.prototype.filterUserRegistrations = function(configuration, options) {
    return ApplicationCommon.filter(configuration, options);
  };

  /**
   * Builds the filter string into the configuration url,
   * based on the options passed in for the User Roles table filter.
   *
   * @param {Object} configuration The Service Data Provider configuration object
   * @param {Object} options The Service Data Provider configuration object
   * @return {Object} The updated Service Data Provider configuration object.
   */
  AppModule.prototype.filterUserRoles = function(configuration, options) {
    return ApplicationCommon.filter(configuration, options, ['Name',
      'EmailAddress'
    ]);
  };

  /**
   * Builds the filter string into the configuration url
   * based on the options passed in for the List Service Requests filter.
   *
   * @param {Object} configuration The Service Data Provider configuration object
   * @param {Object} options The Service Data Provider options object
   * @return {Object} The updated Service Data Provider configuration object.
   */
  AppModule.prototype.filterServiceRequests = function(configuration,
    options) {
    return ApplicationCommon.filter(configuration, options, ['SrNumber',
      'Title'
    ]);
  };

  /**
   * Builds the filter string into the configuration url
   * based on the options passed in for the List Work Orders filter.
   *
   * @param {Object} configuration The Service Data Provider configuration object
   * @param {Object} options The Service Data Provider configuration object
   * @return {Object} The updated Service Data Provider configuration object.
   */
  AppModule.prototype.filterWorkOrders = function(configuration,
    options) {
    return ApplicationCommon.filter(configuration, options, ['WoNumber',
      'Title'
    ]);
  };

  /**
   * Takes a sort criteria String which contains the field and
   * direction separated by a colon, and returns a sortCriteria
   * object which can be used by a Service Data Provider.
   *
   * @param {type} sortAttribute
   * @return {undefined}
   */
  AppModule.prototype.getSortCriteria = function(sortAttribute) {
    return ApplicationCommon.getSortCriteria(sortAttribute);
  };

  /**
   * Takes a number and returns a formatted filesize string.
   *
   * @param {type} number The fileszie
   *
   * @return {undefined}
   */
  AppModule.prototype.getFormattedFilesize = function(filesize) {
    return ApplicationCommon.getFormattedFilesize(filesize);
  };

  /**
   * Extract the accounts that a user belongs to from their mySelfServiceRoles.
   *
   * @param {array} roles roles returned by mySelfServiceRoles API, must have
   *                      AccountPartyId and AccountPartyName fields as a minimum
   * @return {array} array of all the user's accounts, each object has a name and partyId
   */
  AppModule.prototype.extractAccountsFromRoles = function(roles) {
    return ApplicationCommon.extractAccountsFromRoles(roles);
  };

  /**
   * Show the CSS progress cursor for the application body.
   */
  AppModule.prototype.showProgressCursor = function() {
    return ApplicationCommon.showProgressCursor();
  };

  /**
   * Show the CSS wait cursor for the application body.
   */
  AppModule.prototype.showWaitCursor = function() {
    return ApplicationCommon.showWaitCursor();
  };

  /**
   * Show the CSS default cursor for the application body.
   */
  AppModule.prototype.showDefaultCursor = function() {
    return ApplicationCommon.showDefaultCursor();
  };

  /**
   * Focus the first element on the page with the odcs-auto-focus style class.
   */
  AppModule.prototype.focusPage = function() {
    return ApplicationCommon.focusPage();
  };

  /**
   * Scrolls to and sets focus on the first element whose id can be found in the active document,
   * looping through the passed in array of element ids.
   * @param {array} subSectionIds an array of html element ids to be used in finding one that exists to scroll to and set focus on
   * @returns {undefined}
   */
  AppModule.prototype.navigateToSubSection = function(subSectionIds) {
    return ApplicationCommon.navigateToSubSection(subSectionIds);
  };

  /**
   * Convert the FileList from the oj-file-picker to array
   * @param {type} fileList
   * @return {array} array of the fileList object
   */
  AppModule.prototype.convertFileListToArray = function(fileList) {
    return ApplicationCommon.convertFileListToArray(fileList);
  };

  /* Read the file binary content.
   *
   * @param {object} inputFile
   * @return {promise} file reader that read the file binary
   */
  AppModule.prototype.readBinaryContentFromFile = function(inputFile) {
    return ApplicationCommon.readBinaryContentFromFile(inputFile);
  };

  /**
   * Gets a localized Error message based on an error code.
   *
   * @param {string} code the error code
   * @return error message
   */
  AppModule.prototype.getErrorMessage = function(code, messages) {
    return ApplicationCommon.getErrorMessage(code, messages);
  };

  /**
   * Generates a KMauthtoken.
   *
   * @param {type} lang
   * @param {type} kmInterfaceId
   * @return KMauthtoken
   */
  AppModule.prototype.getKMauthtoken = function(lang, kmInterfaceId) {
    return KnowledgeCommon.getAuthtoken(lang, kmInterfaceId);
  };

  /**
   * Gets the language to use in the knowledge kmauthtoken header based on the oJet language,
   * the available locales on the KM server and defaults from the application configuration.
   *
   * @param {Object} localesFromServer the result of calling knowledge-service > getLocales
   * @param {Object} configDefaults application configured default locales for each language
   * @return {string} a String of the form <lang>_<locale>
   */
  AppModule.prototype.getKMLanguage = function(localeFromServer,
    kmLanguageDefaults) {
    return KnowledgeCommon.getLanguage(localeFromServer,
      kmLanguageDefaults);
  };

  /**
   * Adds search terms to the query defined by the configuration's URL.
   *
   * @param {Object} configuration config object with a url property that will have query parameters added to
   * @param {Object} options object defining query criteria
   * @param {string} [options.question] the search terms
   * @param {string} [options.productId] the product ID to be included in the search query
   * @param {string} [options.categoryId] the category ID to be included in the search query
   * @param {number} [options.pageSize] an optional limit to the number of articles to be retrieved
   * @returns {Object} the updated configuration object
   */
  AppModule.prototype.setRequestParams = function(configuration, options) {
    return KnowledgeCommon.setRequestParams(configuration, options);
  };

  /**
   * This method create referenceKey for category/product from response.
   *
   * @param {type} response
   * @param {type} childKey referenceKey of child
   * @param {type} type category or product
   * @return referenceKey
   */
  AppModule.prototype.getReferenceKey = function(response, childKey, type) {
    return KnowledgeCommon.getReferenceKey(response, childKey, type);
  };

  /**
   * Sets the response body results field with the parsed KM articles.
   *
   * @param {type} response KM Articles response we get back from the REST call
   * @param {String} [version] the version number of the ODCS calling application
   * @return response with parsed KM Articles in the body results
   */
  AppModule.prototype.transformAnswers = function(response, version) {
    return KnowledgeCommon.transformAnswers(response, version);
  };

  /**
   * This handle the facet selection to keep track of multiple selection
   *
   * @param {type} event
   * @param {type} model
   * @param {type} binding
   * @return {undefined}
   */
  AppModule.prototype.facetSelection = function(event, model, binding) {
    KnowledgeCommon.facetSelection(event, model, binding);
  };

  /**
   * Create the ArrayTreeDataProvider for the facets
   * @param {type} facets
   * @return {undefined}
   */
  AppModule.prototype.getFacetArrayTreeDataProvider = function(facets) {
    return KnowledgeCommon.getFacetArrayTreeDataProvider(facets);
  };

  /**
   * Returns the  I18n string for knowledge article content types
   * @param {type} contentType article content type from the KM server
   * @return corresponding I18n string
   */
  AppModule.prototype.getKmArticleTitleI18nString = function(contentType) {
    return KnowledgeCommon.getKmArticleTitleI18nString(contentType);
  };

  /**
   * Get the fileType of an article given in the eventDetail part.
   * @param {object} eventDetail the event.detail part of the answer list selection change event
   * @return {string} fileType the fileType of the item selected inside the eventDetail
   */
  AppModule.prototype.getArticleType = function(eventDetail) {
    return KnowledgeCommon.getArticleType(eventDetail);
  };

  /**
   * Get the icon depending on the content type
   * @param {String} contentType article content type from the KM server
   * @return {String} the icon for class
   */
  AppModule.prototype.getArticleIcon = function(contentType) {
    return KnowledgeCommon.getArticleIcon(contentType);
  };

  /**
   * Get the url of an attachment given in the eventDetail part.
   * @param {object} eventDetail the event.detail part of the answer list selection change event
   * @return {string} url the url of the item selected inside the eventDetail
   */
  AppModule.prototype.getAttachmentUrl = function(eventDetail) {
    return KnowledgeCommon.getAttachmentUrl(eventDetail);
  };

 /**
   * Sets the focus on an element after the page has finished loading.
   * One reason this is necessary is to fix IE tab navigation. Depending on what parameters are passed in
   * this function will set focus on a specific element if only elementID is passed in, if an elementID and
   * className are passed in focus will be set on the first child element matching the className, if an index
   * is passed in a specific index of the className retrieved elements will be focused on. If no elementId is
   * provided then all selected elements matching the className will be retrieved and the first element focused upon,
   * otherwise if an index is provided that will be used to determine which element is focused on.
   *
   * @param {string} [elementID] The optional id of the element
   * @param {string} [className] The optional className of the element or elements being targeted, which if provided with an elementId will target that element's children
   * @param {number} [index] The optional index of the element being targeted, to be used in conjunction with the className, if not set defaults to 0
   * @return undefined
   */
  AppModule.prototype.setItemFocus = function(elementID, className, index) {
    ApplicationCommon.setItemFocus(elementID, className, index);
  };

  /**
   * Takes a key and value, sets the value for the key in the object and returns the updated object.
   *
   * @param {object} map An object to add/update the key with the value passed in
   * @param {String} key Key for which value is to be set/updated in the object
   * @param {object} value Value to be set/updated
   * @return {object} Updated map object
   */
  AppModule.prototype.setMapKeyValue = function(map, key, value) {
    return ApplicationCommon.setMapKeyValue(map, key, value);
  };

  /**
   * Checks a validator detail object for validity, and if invalid sets the disabled
   * attribute to true, otherwise it is set to false.
   *
   * @param {object} detail The validator event payload, provided by the onValidityChange event
   * @param {String} element The id of the elements whose disabled flag should be updated based on validity
   */
  AppModule.prototype.disableElementOnInvalid = function(detail, elementId) {
    ApplicationCommon.disableElementOnInvalid(detail, elementId);
  };

  /**
   * Sets a cookie.
   *
   * @param {String} cookieName the name of the cookie to set
   * @param {String} cookieValue the value to assign to the cookie
   * @param {number} [exdays] the number of days before the cookie expires or 365 if not specified
   */
  AppModule.prototype.setCookie = function(cookieName, cookieValue, exdays) {
    return ApplicationCommon.setCookie(cookieName, cookieValue, exdays);
  };

  /**
   * Gets the value of a cookie.
   *
   * @param {String} cookieName the name of the cookie to get
   * @return {string} the value of the cookie or an empty string if the cookie is not set
   */
  AppModule.prototype.getCookie = function(cookieName) {
    return ApplicationCommon.getCookie(cookieName);
  };

  /**
   * Builds the filter string into the configuration url,
   * based on the options passed.
   * Example query criteria could be:
   * "categories.refKey eq 'FUSION_CATEGORY_300100095920022'"
   *
   * @param {Object} configuration The Service Data Provider configuration object
   * @param {Object} options The query criteria
   * @return {Object} The updated Service Data Provider configuration object.
   */
  AppModule.prototype.appendFilterQueryOptions = function(configuration,
    options) {
    return ApplicationCommon.appendFilterQueryOptions(configuration,
      options);
  };

  /**
   * Checks all the attributes of an object against a passed in testValue.
   * The testValue can either be an object or simple value such as a string or
   * boolean. If the test value is an object equality is tested against the validation
   * objects attributes, otherwise if it is not an object all the validation attributes
   * are tested to match the testValue. Note if an attribute of the objectToValidate
   * has a false value and there is not corresponding attribute on the testValue, or that value
   * is also false this is deemed an attribute match. However, if the corresponding testValue
   * attribute does exist and has a truthy value this is deemed not a match.
   * This could be used to check a state object is ready to move on to invoke an
   * operation, or whether it is in a not ready state. For example the Knowledge Search
   * can only be invoked once a product selection process has finished, and
   * the search question is submitted, these states can be held on a object
   * passed into this function, to ascertain whether the query is ready to be
   * invoked.
   * @param {Object} objectToValidate The object whose attributes are to be tested
   * @param {Object} testValue The test value to be used to validate attribute values
   * if this is an object a match of the attributes and value in both objects is performed.
   * @return {boolean} The result of testing whether all the object's attributes values
   * match the testValue value or if testValue is an object the testValue's attributes or not,
   * true is returned if that is correct, otherwise false.
   */
  AppModule.prototype.areAttributesMatchingTestValue = function(
    objectToValidate, testValue) {
    return ApplicationCommon.areAttributesMatchingTestValue(
      objectToValidate, testValue);
  };

  /**
   * Open the dialog to enable access to it, taking the id of the dialog to be opened
   *
   * @param {String} dialogElementId The id of the dialog component to open,
   * @param {integer} [minWidthOverride=500] The minimum width the dialog should be
   * @param {integer} [minHeightOverride=300] The minimum height the dialog should be
   */
  AppModule.prototype.openDialog = function(dialogElementId,
    minWidthOverride, minHeightOverride) {
    return ApplicationCommon.openDialog(dialogElementId, minWidthOverride,
      minHeightOverride);
  };

  /**
   * Closes the dialog box for the passed in element id
   *
   * @param dialogElementId The id of the dialog component to close
   */
  AppModule.prototype.closeDialog = function(dialogElementId) {
    return ApplicationCommon.closeDialog(dialogElementId);
  };

  /**
   * Looks up a property from an object
   *
   * @param {Object} lookupObject the object from which the value should be retrieved from.
   * @param {String} key the key to lookup the value from.
   * @return {Object} the value of the key looked up from the lookup object.
   */
  AppModule.prototype.getValueFromObject = function(lookupObject, key) {
    return ApplicationCommon.getValueFromObject(lookupObject, key);
  };

  /**
   * Adds an entry to an array and returns the updated array
   *
   * @param {Object} entry the entry to add to the target array
   * @param {Array} targetArray the target array into which the entry is added
   * @return {Array} the updated target array
   */
  AppModule.prototype.pushValueToArray = function(targetArray, entry) {
    return ApplicationCommon.pushValueToArray(targetArray, entry);
  };

  /**
   * Returns a delimited list of attribute values retrieved by looking up passed in record
   * entries from a lookup object.
   *
   * @param {Array} records array containing the attribute names to lookup
   * @param {Object} lookupObject object to lookup from
   * @param {String} attributeName the attribute to retrieve a value from out of the lookup object entry
   * @param {String} delimiter the characters used to delimit the result, e.g. ', '
   * @return {String} the value of the looked up attributes values, delimited by the delimiter
   */
  AppModule.prototype.getDelimitedListOfAttributesLookingUpFromArrayOfObjects =
    function(records, lookupMap, attributeName, delimiter) {
      return ApplicationCommon.getDelimitedListOfAttributesLookingUpFromArrayOfObjects(
        records, lookupMap, attributeName, delimiter);
    };

  /**
   * Checks to see if two arrays are the same based on having the same values,
   * if any are added or removed a false result is returned, otherwise it is true
   *
   * @param {Array} arrayA an array to perform the comparison
   * @param {Array} arrayB the other array to perform the comparison
   * @return {Boolean} true if the values match, otherwise false
   */
  AppModule.prototype.areArraysValuesMatching = function(arrayA, arrayB) {
    return ApplicationCommon.areArraysValuesMatching(arrayA, arrayB);
  };

  /**
   * Returns an array of elements only present in the source array, excluding
   * all those present in the compare array.
   *
   * @param {Array} sourceArray the source array to be examined
   * @param {Array} compareArray the compare array whose entries should not be returned if found in the source array
   * @return {Array} the array of items only in the source array
   */
  AppModule.prototype.getArrayOfItemsCommonToSourceArray = function(
    sourceArray,
    compareArray) {
    return ApplicationCommon.getArrayOfItemsCommonToSourceArray(
      sourceArray,
      compareArray);
  };

  /**
   * Removes a specified key from an array, and returns the updated array
   *
   * @param {Array} sourceArray the array from which to remove the entry
   * @param {String} key the key to remove
   * @return {Array} the updated array missing the passed in entry
   */
  AppModule.prototype.removeEntryFromArray = function(sourceArray, key) {
    return ApplicationCommon.removeEntryFromArray(sourceArray, key);
  };

  /**
   * Updates the target Object with a property derived from a lookup on the source array's objects,
   * using a key to match on a value. The source array entry once found is used to map a lookup attribute's
   * value to a target attribute's value before being set on the target Object and returned.
   * An example usage of this function would be the User Management component adding a new role
   * to a map where the attributes on source and target need manipulating.
   *
   * @param {Object} targetObject the target Object to add a mapped entries from the source array
   * @param {Array} sourceArray the source array containing Objects to look up the key attribute's values from
   * @param {String} key the key to lookup the entry from the source array's objects
   * @param {String} lookUpReference the lookup attribute name whose value needs to match the key
   * @param {String} attributeFromLookup the source object's attribute name whose value is to be mapped to the target
   * @param {String} attributeToTarget the target's attribute name whose value is retrieved from the source via the lookup
   * @return {Object} the updated target Object containing the entries from the source array matching the passed in key and mapped to
   * the passed in target attribute
   */
  AppModule.prototype.updateTargetObjectWithLookupCodeEntryFromSourceArrayBasedOnKey =
    function(targetObject, sourceArray,
      key, lookUpReference, attributeFromLookup, attributeToTarget) {
      return ApplicationCommon.updateTargetObjectWithLookupCodeEntryFromSourceArrayBasedOnKey(
        targetObject, sourceArray,
        key, lookUpReference, attributeFromLookup, attributeToTarget);
    };

  /**
   * Build an object based on the passed in array excluding and object's array collection attribute's
   * elements whose attribute and attribute value match those passed in.
   *
   * @param {Object} sourceObject The Object containing the array and array of objects to be examined
   * @param {String} sourceObjectCollectionKey The attribute key of the Objects array collection attribute
   * @param {String} attributeKey The key name to be examined on each of the Object\'s array property\'s elements
   * @param {Object} attributeValue The value of the array element's key that should be excluded in the returned array
   * @return {Array} An array of the array elements from the Object excluding any that has an attribute and value
   * that should have been excluded.
   */
  AppModule.prototype.getSourceObjectsCollectionArrayExcludingAttributeValueEntry =
    function(sourceObject, sourceObjectCollectionKey,
      attributeKey, attributeValue) {
      return ApplicationCommon.getSourceObjectsCollectionArrayExcludingAttributeValueEntry(
        sourceObject, sourceObjectCollectionKey,
        attributeKey, attributeValue);
    };

  /**
   * Returns an Array of the values of an attribute in each of the array members.
   *
   * @param {Array} objectArray The array to loop through and retrieve the passed in attribute values
   * @param {Array} attributeName The attribute key used to look up values to be added to the result array
   * @return {Array} the array of values representing an array's members specific attribute.
   */
  AppModule.prototype.getArrayOfArrayObjectsAttributesAttributeValue =
    function(objectArray, attributeName) {
      return ApplicationCommon.getArrayOfArrayObjectsAttributesAttributeValue(
        objectArray, attributeName);
    };

  /**
   * Creates an object allowing access to name and id values from a
   * an object. It builds a subset of objects keys from a lookup
   * objects, setting the attributes when there is a match on the subsetAndTargetKey and lookupKey
   * to name and id attributes on the look up object being built.
   * An example usage of this function can be found in the User Management modules
   * where the delete code requires an id to delete a user and a name to display in
   * the confirmation message.
   *
   * @param {Array} subsetSet The subset to be used in building the object through lookups to a full set
   * @param {String} subsetAndTargetKey The key to use both in looking up an entry from the subset and
   * for using as the key name when building the result object
   * @param {Array} lookupSet The subset to be used in building the object through lookups to a full set
   * @param {String} lookupKey The key to use in retrieving an entry that matches the value of the subsetAndTargetKey
   * attribute's value from the subsetSet
   * @param {String} lookupIdAttr Attribute in the source set to use in mapping to the object's id attribute
   * @param {String} lookupNameAttr Attribute in the source set to use in mapping to the object's name attribute
   * @return {Object} The object representing the combined data sets and attribute mappings mapped to name and id attributes.
   */
  AppModule.prototype.getLookupObjectMappingKeyAndLookupValuesToNameIdAttributes =
    function(subsetSet,
      subsetAndTargetKey,
      lookupSet, lookupKey,
      lookupIdAttr, lookupNameAttr) {
      return ApplicationCommon.getLookupObjectMappingKeyAndLookupValuesToNameIdAttributes(
        subsetSet, subsetAndTargetKey,
        lookupSet, lookupKey,
        lookupIdAttr, lookupNameAttr);
    };

  /**
   * Returns value of passed in attribute from the object that has the passed in attribute-value pair.
   * It loops through the objectArray looking for the object with the testAttributeKey-testAttributeValue pair
   * and returns the value of the attributeToRetrieve from the same object
   *
   * @param {Array} objectArray Array of objects to loop through to retrieve object with passed in key-value pair
   * @param {String} testAttributeKey Attribute name of the attribute to match the value of
   * @param {String} testAttributeValue Value to test against the testAttributeKey
   * @param {String} attributeToRetrieve Name of the attribute whose value is to be retrieved
   * @return {Object} value of the required attribute
   */
  AppModule.prototype.getValueFromObjectWithKeyValuePair =
    function(objectArray, testAttributeKey, testAttributeValue,
      attributeToRetrieve) {
      return ApplicationCommon.getValueFromObjectWithKeyValuePair(
        objectArray, testAttributeKey, testAttributeValue,
        attributeToRetrieve);
    };

  /**
   * Returns an object with account and roles information extracted from the mySelfServiceRoles response
   *
   * @param {Array} responseItems Items array from the mySelfServiceRoles response body
   * @param {String} accounts Accounts application variable object
   * @return {Object} Object containing entries of accounts and corresponding roles
   */
  AppModule.prototype.getAccountAndRolesObject = function(responseItems,
    accounts) {
    return ApplicationCommon.getAccountAndRolesObject(responseItems,
      accounts);
  };

  /**
   * Returns an object with the most recent date for the passed in date
   * attribute, adding to the object a passed in attribute and value.
   * An example usage of this is in the user management flows where
   * there is a requirement to show the user's most recent update to
   * any of the roles that have been assigned to the user.
   * @param {Array} objectArray - list of user roles returned by the API
   * @param {String} dateAttribute - list of user roles returned by the API
   * @param {String} attributeKey - list of user roles returned by the API
   * @param {String} attributeValue - list of user roles returned by the API
   * @return {Object} the object with the most recent date with the added attribute and value
   */
  AppModule.prototype.getObjectFromArrayByMostRecentDateAndAddAttributeValue =
    function(objectArray, dateAttribute, attributeKey, attributeValue) {
      return ApplicationCommon.getObjectFromArrayByMostRecentDateAndAddAttributeValue(
        objectArray, dateAttribute, attributeKey, attributeValue);
    };

  /**
   * Extracts article content and various pieces of metadata from a KM content response.
   *
   * @param {Object} content article content from the KM server
   * @param {string} locale the locale to use for attribute names
   * @param {Object} contentType localized attribute names for the article's Content Type
   * @param {string} OPASiteUrl the OPA site URL to be used for the OPA in the knowledge Article
   * @param {string} OPAHubServiceId the Service ID to retrieve the OPA Site URL if it is not specified
   * @param {Object} options context object containing data for additional parameters currently used in the OPA element
   * @param {Array<{ name: string; value: string; }>} [options.opaInterviewAttributes] optional OPA url attributes to be included in opa elements
   * @param {string} [options.opaInterviewConfigurationWarningPlaceholder] optional string to be used as HTML markup to be shown on encountering an
   * Intelligent Advisor site URL configuration issue.
   * @return formatted article and metadata
   */
  AppModule.prototype.transformKMContent = function(response, locale,
    contentType, OPASiteUrl, OPAHubServiceId, options) {
    return KnowledgeCommon.parseAnswerContent(response.body, locale,
      contentType, OPASiteUrl, OPAHubServiceId, options);
  };

  /**
   * Processes attributes for a single Content Type and returns an Object that defines translations
   * for each attribute of the Content Type.
   *
   * @param {Object} response the result of calling knowledge-service > getContentTypeById
   * @return {Object} translations for each attribute of the Content Type
   */
  AppModule.prototype.processKMContentTypeDefinition = function(response) {
    return KnowledgeCommon.processContentTypeDefinition(response);
  };

  /**
   * Adds fields to an aggregateFormResults object to allow rating information for a knowledge article
   * to be displayed. The exact fields that are added depends on the type of rating being used for the
   * article. A aggregateFormResults.rated property will always be added and set to true if rating
   * information is in a recognised format was found or false otherwise.
   *
   * @param {Object} aggregateFormResults the aggregate form results object to be processed
   * @return the aggregateFormResults object that was passed in with additional information added
   */
  AppModule.prototype.processRatingData = function(aggregateFormResults) {
    return KnowledgeCommon.processRatingData(aggregateFormResults);
  };

  /**
   * Creates an asynchronous validator for the 'new password' field that ensures that IDCS password policies
   * are adhered to. This is implemented by making requests to the IDCS User Password Validator
   * REST API.
   *
   * @param {String} selector selector for the password field to attach additional violation messages to
   * @param {String} userId ID of the user to validate the password for
   * @param {String} password the new password entered by the user
   * @param {object} resourceBundle contains properties for custom translations of policy violation error messages
   * in the form idcsPasswordPolicyViolation_[policy-key] e.g.: idcsPasswordPolicyViolation_minLength
   * @return {Array} an array containing an AsyncValidator for IDCS password policies
   */
  AppModule.prototype.passwordPolicyValidator = function(selector, userId,
    password, resourceBundle) {
    var serviceId = 'idcsRestApi/putUserPasswordValidatorUserId';
    var language = oj.Config.getLocale();
    return IdcsUtils.passwordPolicyValidator(selector, userId, password,
      serviceId, language, resourceBundle);
  };

  /**
   * Creates a validator for the 'repeat new password' field that ensures that the
   * values in the new password and repeated new password fields match.
   *
   * @param {String} selector selector for the first password field to check the confirmed
   * password value against
   * @param {String} message translated error text to be displayed if validation fails
   * @return {Array} an array containing a Validator for password fields
   */
  AppModule.prototype.passwordsMatchValidator = function(selector, message) {
    return IdcsUtils.passwordsMatchValidator(selector, message);
  };

  /**
   * Determines whether the user of the current browser session is authenticated with IDCS.
   *
   * @return {Promise<boolean>} resolves to true if the current browser user is authenticated with IDCS
   */
  AppModule.prototype.isIdcsUserAuthenticated = function() {
    return IdcsUtils.isIdcsUserAuthenticated(this.getIdcsClientId(), this.getIdcsRedirectUrl());
  };

  /**
   * Merges two objects and returns a combined object.
   * Properties in the target object will be overwritten by
   * properties in the sources if they have the same key.
   *
   * @param {Object} targetObject The target object
   * @param {Object} sourceObject The source object
   * @return {Object} The target object updated with source object attributes.
   */
  AppModule.prototype.mergeObjects = function(targetObject, sourceObject) {
    return ApplicationCommon.mergeObjects(targetObject,
      sourceObject);
  };

  /**
   * Return whether the user's browser is supported, Internet Explorer
   * is not supported by DCS.
   *
   * @return {boolean} true if the browser is supported; false otherwise
   */
  AppModule.prototype.isSupportedBrowser = function() {
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf('MSIE'); // IE10 and below
    var trident = ua.indexOf('Trident/'); // IE11
    if (msie >= 0 || trident >= 0) {
      return false;
    }

    return true;
  };

  /**
   * Checks whether the application is configured to use the OdcsSecurityProvider.
   *
   * @return {boolean} true if the application is using the OdcsSecurityProvider;
   * false otherwise
   */
  AppModule.prototype.isUsingOdcsSecurityProvider = function() {
    return OdcsSecurityProvider.getCurrent() !== undefined;
  };

  /**
   * Resets the custom login state if the OdcsSecurityProvider is being used.
   * 
   * @return {undefined}
   */
  AppModule.prototype.resetCustomLoginState = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.resetLoginState();
  };

  /**
   * Indicates that a successful IDCS login has been performed in a custom login flow if the OdcsSecurityProvider is
   * being used.
   * 
   * @return {undefined}
   */
  AppModule.prototype.customIdcsLoginPerformed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.idcsLoginPerformed();
  };

  /**
   * Indicates that a successful VBCS login has been performed in a custom login flow if the OdcsSecurityProvider is
   * being used.
   * 
   * @return {undefined}
   */
  AppModule.prototype.customVbcsLoginPerformed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.vbcsLoginPerformed();
  };

  /**
   * Indicates that a custom login flow has successfully finished if the OdcsSecurityProvider is
   * being used.
   *
   * @return {undefined}
   */
  AppModule.prototype.customLoginComplete = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.loginComplete();
  };

  /**
   * Indicates that a custom login flow has failed to complete successfully if the OdcsSecurityProvider is
   * being used.
   * 
   * @return {undefined}
   */
  AppModule.prototype.customLoginFailed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.loginFailed();
  };
  
  /**
   * Indicates that an external IDP login has been performed in a custom login flow if the OdcsSecurityProvider is
   * being used.
   * 
   * @return {undefined}
   */
  AppModule.prototype.externalLoginPerformed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.externalLoginPerformed();
  };    

  /**
   * @return {boolean} true if a custom login flow has completed IDCS login (but
   * VBCS login is still to be completed)
   */
  AppModule.prototype.isCustomIdcsLoginPerformed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp ? (sp.getLoginState() === 'idcs-login-performed') : false;
  };

  /**
   * @return {boolean} true if a custom login flow has completed VBCS login (after
   * completing the IDCS login)
   */
  AppModule.prototype.isCustomVbcsLoginPerformed = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp ? (sp.getLoginState() === 'vbcs-login-performed') : false;
  };

  /**
   * @return {boolean} true if a custom login flow is being used and is in either post IDCS login or
   * post VBCS login state, indicating that a custom login is in progress
   */
  AppModule.prototype.isCustomLoginInProgress = function() {
    return (this.isCustomIdcsLoginPerformed() || this.isCustomVbcsLoginPerformed());
  };

  /**
   * Gets the /protected URL used to perform VBCS login once the user is authenticated with IDCS.
   *
   * @return {string} the /protected URL
   */
  AppModule.prototype.getProtectedUrl = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.getProtectedUrl();
  };   

  /**
   * Checks the response from a call to the IDCS /admin/v1/MePasswordRecoveryOptionRetriever API to ensure that
   * email based password reset is supported.
   *
   * @param {Object} response a response from a call to the IDCS Users API
   * @return {String} the masked email address format from the response or undefined if password based recovery is
   * not supported
   */
  AppModule.prototype.checkIdcsPasswordRecoveryOptions = function(response) {
    return IdcsUtils.checkPasswordRecoveryOptions(response);
  };

  /**
   * Gets the current OJet locale.
   */
  AppModule.prototype.getOJetLocale = function() {
    return oj.Config.getLocale();
  };

  /**
   * Extracts and decodes Login Context data from the HTML form that is returned by the IDCS /authorize endpoint.
   *
   * @param {String} html markup for an HTML page containing a form
   * @param {String} jwt the initial IDCS access token
   * @return {Promise} that resolves to the decrypted value of the loginCtx parameter in the form
   */
  AppModule.prototype.processIdcsAuthorizeHtmlForm = function(html, jwt) {
    return IdcsUtils.processAuthorizeHtmlForm(html, jwt);
  };

  /**
   * Obtains a JWT token for a REST API.
   *
   * @param {String} serviceId the ID of the VBCS service for the REST API
   */
  AppModule.prototype.getJwt = function(serviceId) {
    return IdcsUtils.getJwt(serviceId);
  };

  /**
   * Performs a full browser window form submission to the URL for a REST endpoint.
   *
   * @param {type} endpoint the REST endpoint that corresponds to the URL to which the
   * form submission is performed
   * @param {Object} params an object defining form parameter name/value pairs
   * @param {String} [method=POST] the HTTP method by which to submit the form
   * @return {Promise} a Promise that resolves when the form submission has been completed
   */
  AppModule.prototype.formSubmitToEndpoint = function(endpoint, params, method) {
    return IdcsUtils.formSubmitToEndpoint(endpoint, params, method);
  };

  /**
   * Obtains the IDCS client ID for the current application if the OdcsSecurityProvider is
   * being used.
   *
   * @return {String} the IDCS client ID
   */
  AppModule.prototype.getIdcsClientId = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.getIdcsClientId();
  };

  /**
   * Obtains the IDCS redirect URL for the current application if the OdcsSecurityProvider is
   * being used.
   *
   * @return {String} the IDCS redirect URL
   */
  AppModule.prototype.getIdcsRedirectUrl = function() {
    var sp = OdcsSecurityProvider.getCurrent();
    return sp && sp.getIdcsRedirectUrl();
  };

  /**
   * Extracts the error code from a failed response from the IDCS /sso/v1/sdk/authenticate
   * REST endpoint.
   *
   * @param {Object} response the failed REST response
   * @return {string} the error code for the failure or undefined if no error code was found
   */
  AppModule.prototype.getIdcsLoginErrorCode = function(response) {
    return IdcsUtils.getLoginErrorCode(response);
  };

  /**
   * Sets the HTML page title to the string that corresponds to the specified application-level
   * resource bundle string, with any parameters expanded.
   *
   * @param {Object} resourceBundle contains properties for translations
   * @param {String} key identifies the string in the resource bundle
   * @param {Object} [params] key-value pairs to be used to expand any parameter values in the string
   */
  AppModule.prototype.setPageTitle = function(resourceBundle, key, params) {
    ApplicationCommon.setPageTitle(resourceBundle, key, params);
  };

  /**
   * Split an array of navigation items into type specific arrays.
   *
   * @param {Array} items navigation items to split
   * @param {Array} types array of types to categorise items into,
   *                      if an item is not one of the specified types it
   *                      will be added to the other array
   * @return {Object} map of type name and 'other' to arrays of corresponding items
   */
  AppModule.prototype.splitItemsByType = function(items, types) {
    return VisualNavigatorCommon.splitItemsByType(items, types);
  };

  /**
   * Join all the items in the supplied items arrays (any number can be
   * supplied) into one array of items ordered by index. It is assumed that each
   * item array is already in index ascending order.
   *
   * @return {Array} items in index order
   */
  AppModule.prototype.joinItemsByIndex = function(items1, items2, items3,
    items4, items5, items6, items7, items8, items9, items10) {
    return VisualNavigatorCommon.joinItemsByIndex(items1, items2, items3,
      items4, items5, items6, items7, items8, items9, items10);
  };

  /**
   * Set the query parameter on a catalogProductItems query to return the
   * products specified by options.
   *
   * @param {Object} configuration query configuration
   * @param {Object} options options for the query
   * @return {Array} updated query configuration
   */
  AppModule.prototype.setProductRequestParameters = function(configuration,
    options) {
    return VisualNavigatorCommon.setProductRequestParameters(
      configuration, options);
  };

  /**
   * Set the query parameter on a categories query to return the
   * categories specified by options.
   *
   * @param {Object} configuration query configuration
   * @param {Object} options options for the query
   * @return {Array} updated query configuration
   */
  AppModule.prototype.setCategoryRequestParameters = function(configuration,
    options) {
    return VisualNavigatorCommon.setCategoryRequestParameters(
      configuration, options);
  };

  /**
   * Set the query parameter on a catalogProductGroups query to return the
   * product groups specified by options.
   *
   * @param {Object} configuration query configuration
   * @param {Object} options options for the query
   * @return {Array} updated query configuration
   */
  AppModule.prototype.setProductGroupRequestParameters = function(
    configuration,
    options) {
    return VisualNavigatorCommon.setProductGroupRequestParameters(
      configuration, options);
  };

  /**
   * Get the ids of items in the supplied array that have not had their
   * title loaded.
   *
   * @param {Array} items array of items to check
   * @return {Array} item ids that do not have a title set
   */
  AppModule.prototype.getMissingItems = function(items) {
    return VisualNavigatorCommon.getMissingItems(items);
  };

  /**
   * Load title and description from the translations bundle for the supplied
   * navigation items if the value specifies a bundle key, i.e. value starts
   * with !.
   *
   * @param {Array} items items to process
   * @param {Object} translations bundle to load translations from
   * @return {Array} processed array of items
   */
  AppModule.prototype.transformStaticItems = function(items, translations) {
    return VisualNavigatorCommon.transformStaticItems(items, translations);
  };

  /**
   * Add information for products in the supplied response to the corresponding
   * navigation items. If an item does not have an imageUrl or icon its
   * imageUrl will also be set to <applicationPath>resources/images/products/<id>.png.
   *
   * @param {Array} items products to augment with information from REST response
   * @param {Object} response REST response for getting information for products
   * @param {String} applicationPath path of application used for building image
   *                                 URLs if a product does not have one set
   * @return {Array} processed array of items
   */
  AppModule.prototype.transformProductItems = function(items, response,
    applicationPath) {
    return VisualNavigatorCommon.transformProductItems(items, response,
      applicationPath);
  };

  /**
   * Add information for products in the supplied response to the corresponding
   * navigation items. If an item does not have an imageUrl or icon its
   * imageUrl will also be set to <applicationPath>resources/images/categories/<id>.png.
   *
   * @param {Array} items categories to augment with information from REST response
   * @param {Object} response REST response for getting information for categories
   * @param {String} applicationPath path of application used for building image
   *                                 URLs if a category does not have one set
   * @return {Array} processed array of items
   */
  AppModule.prototype.transformCategoryItems = function(items, response,
    applicationPath) {
    return VisualNavigatorCommon.transformCategoryItems(items, response,
      applicationPath);
  };

  /**
   * Add information for product groups in the supplied response to the corresponding
   * navigation items. If an item does not have an imageUrl or icon its
   * imageUrl will also be set to <applicationPath>resources/images/product-groups/<id>.png.
   *
   * @param {Array} items products to augment with information from REST response
   * @param {Object} response REST response for getting information for product groups
   * @param {String} applicationPath path of application used for building image
   *                                 URLs if a product group does not have one set
   * @return {Array} processed array of items
   */
  AppModule.prototype.transformProductGroups = function(items, response,
    applicationPath) {
    return VisualNavigatorCommon.transformProductGroups(items, response,
      applicationPath);
  };

  /**
   * Compare two arrays of items for differences in their basic configuration
   * to check whether the loaded navigator items should be reloaded. Each item
   * of the array is compared on type, operation and id.
   *
   * @param {Array} items1 first array of items
   * @param {Array} items2 second array of items
   * @return true if the items are basically the same
   */
  AppModule.prototype.itemsEquals = function(items1, items2) {
    return VisualNavigatorCommon.itemsEquals(items1, items2);
  };

  /**
   * Load a JSON file into a JavaScript object.
   *
   * @param {String} path path of JSON file in resources directory
   * @return {Promise} promise that when resolved return the JSON specified
   *                   by path parsed into an object
   */
  AppModule.prototype.loadJSON = function(path) {
    return new Promise(function(resolve/*, reject*/) {
      require([
        'text!./resources/' + path
      ], function(data) {
        resolve(JSON.parse(data));
      });
    });
  };

  /**
   * Returns a string of '&' prepended parameters and associated values
   * from the urlParameters argument passed in or if urlParameters is undefined from the
   * current url's parameter list, excluding those parameters whose attribute names are
   * in the specified exclusionsArray. If it is required the recurseValues flag allows
   * recursively using to the exclude parameter's values as names of attributes to also remove.
   * For example, if the url parameters are:
   *   ?page=myPage&shell=myShell&myShell=myShellHomepage&expectedParam=someValue
   * specifying 'page' as a parameter to exclude with the recurseValues set to true would lead to only:
   *   &expectedParam=someValue
   * being returned.
   *
   * @param {String[]} exclusionsArray Array of strings representing the parameter names not to add to the result set
   * @param {Boolean} recurseValues Flag to indicate whether to also recursively remove parameters whose name matches the value of
   * an exclusion array's parameter's value.
   * @param {String} [urlParameters] url parameters string to use in getting a set of parameters excluding
   * page and shell attributes. If this is undefined the window.location.search is used, ie the
   * current browser's url parameters.
   * @return {String} The parameters and values prepended with '&' from the url, excluding those specified in the exclusions list
   */
  AppModule.prototype.getUrlParametersWithExclusions = function(
    exclusionsArray, recurseValues, urlParameters) {
    return ApplicationCommon.getUrlParametersWithExclusions(
      exclusionsArray, recurseValues, urlParameters);
  };

  /**
   * Creates an array with the entries based on parameters passed in
   * ignoring undefined parameter values.
   *
   * @param {*} param1 value to add to the array, if defined.
   * @param {*} param2 value to add to the array, if defined.
   * @return {[*]} An array populated with defined values, or an empty array if no
   *    defined parameters are passed in.
   */
  AppModule.prototype.createArrayWithDefinedParameters = function(param1,
    param2) {
    return ApplicationCommon.createArrayWithDefinedParameters(param1,
      param2);
  };

  /**
   * Constructs a new ArrayTreeDataProvider with the provided data and options.
   * These data providers are typically used by oj-treeView components.
   *
   * @param {Array|funtion():Array} data data supported by the components. This can be either an Array, or a Knockout observableArray.
   * @param {Object} [options] Optional options to be used by the constructor
   * @return {ArrayTreeDataProvider} options Options for the ArrayTreeDataProvider
   */
  AppModule.prototype.createArrayTreeDataProvider = function(data, options) {
    return ApplicationCommon.createArrayTreeDataProvider(data, options);
  };

  /**
   * Utility function providing access to perform various operations associated
   * with arrays and items.
   * Operations available are:
   * 'includes' -  determines whether an array includes a certain value among its entries, returning true or false as appropriate.
   * 'remove' - creates a new array with all elements excluding the item passed in.
   * 'push' - adds the item to the end of an array if the item is not present and returns the array.
   *  The 'push' operation can be further controlled using the options argument. To allow
   *  only truthy and not included items {'truthyNoDuplicates': true}
   * 'updateArrayRemovingDotDefinedParentsAndChildren' - Updates the array with the new item, removing the
   * value's parent if previously in the array. Parents are denoted by being the
   * string before the initial '.' character. Children are also removed, children being
   * entries that start with the itemValue, for example grandparent.parent.child would be
   * removed if the itemValue is grandparent.parent.
   * For a parent example if the itemValue is 'parent.child' as a value would look to remove any
   * item with the value 'parent', and then add the entry with value 'parent.child'
   * 'addItemDotDefinedParentToArray' - Adds an item's parent to an array.
   * The item's parents if present can be determined by searching
   * for the first index of a '.' character and then extracting that part of the string.
   *
   * @param {string} operation the operation to perform
   * @param {[Object]} array the array to use in performing the operation
   * @param {* | string} item the item to use in performing the operation, some operations should be passed a String item as detailed in the
   * jsdoc.
   * @param {Object} [options] options that can be passed to alter behaviour
   * @return {Object} The result of the operation, which will be specific to the operation invoked
   * @throws {TypeError} Will throw an error if an unknown operation is passed in
   */
  AppModule.prototype.arrayOperation = function(operation, array, item,
    options) {
    return ApplicationCommon.arrayOperation(operation, array, item,
      options);
  };

  /**
   * Takes an Object, and an attribute name and a value, and updates the Object's attribute matching
   * that name with the value, then returns the updated object.
   *
   * @param {Object} object The Object whose attribute will be updated with the value
   * @param {String} attribute The attribute on the Object to set the value on
   * @param {String} value The value to set on the Object's attribute
   * @return {Object} the updates object
   */
  AppModule.prototype.updateObjectAttributeValue = function(object,
    attribute, value) {
    return ApplicationCommon.updateObjectAttributeValue(object, attribute,
      value);
  };

  /**
   * Performs operations on keySets that map to id attributes on the keySets object.
   * The keySets object may hold any number of keySet objects as the values of the top level
   * attributes, the object may be of this structure, once the add and get operations have
   * been invoked for different ids like 'PRODUCTS', 'CATEGORIES' and 'DOCUMENT_TYPES'
   *   {
   *     'PRODUCTS': keySetObjectContainingProducts,
   *     'CATEGORIES': keySetObjectContainingCategories,
   *     'DOCUMENT_TYPES': keySetObjectContainingDocumentTypes,
   *   }
   * Supported operations are 'get', 'add', 'clear'.
   * 'get' will ensure that a keySet object exists mapping to the id attribute passed into the function call,
   * it will construct the keySet if required and assign it to the keySets Object.
   * 'add' will add an entry or entries to the keySet mapping to the id passed in on the keySets object.
   * 'clear' will clear the keySet mapping to the id passed in on the keySets object.
   * 'addWithRecursiveParents'
   * After the operation is performed the keySets Object is updated and returned.
   * @param {string} operation The operation to perform on the keyset
   * @param {Object} keysets The Object containing id mapped keySets
   * @param {string} [id] The id of the keySet attribute to create or perform actions on in the keySets Object
   * @param {string | [string]} [entry] The name of the attribute whose keySet is required
   * @return {Object} The object containing id mapped keySets
   * @throws {TypeError} Will throw an error if an unknown operation is passed in
   */
  AppModule.prototype.keySetOperation = function(operation, keySets, id,
    entry) {
    return ApplicationCommon.keySetOperation(operation, keySets, id,
      entry);
  };

  /**
   * Returns a regExp validator object. Typically used in a validation array for an
   * oj-input-text component.
   *
   * @param {String} pattern the regular expression pattern to use when constructing the validator
   * @param {String} messageDetail the message detail
   * @param {String} [hint] the hint message for the validator
   * @return {Object} the validator object
   */
  AppModule.prototype.getRegExpValidatorItem = function(pattern,
    messageDetail, hint) {
    return ApplicationCommon.getRegExpValidatorItem(pattern,
      messageDetail, hint);
  };

  /**
   * Returns an array of validators which can be used in the validators option of an oj-input-text component.
   *
   * @param {Array} validators the array of validator items
   * @return {ko.pureComputed} a ko.pureComputed object that returns an array containing the passed in validators
   */
  AppModule.prototype.getValidatorArray = function(validators) {
    return ApplicationCommon.getValidatorArray(validators);
  };

  /**
   * Decode a base-64 encoded string in a way that supports unicode
characters.
   *
   * @param {string} value the base-64 encoded string to decode
   * @return {string} the decoded string
   */
  AppModule.prototype.base64DecodeUnicode = function(value) {
    return ApplicationCommon.base64DecodeUnicode(value);
  };

  /**
   * Encode a string to base-64 in a way that supports unicode characters.
   *
   * @param {string} value the string to encode
   * @return {string} the base-64 encoded string
   */
  AppModule.prototype.base64EncodeUnicode = function(value) {
    return ApplicationCommon.base64EncodeUnicode(value);
  };

  /**
   * Gets a width percentage to use when stamping out different quantities
   * of items based on the screen size, maximum number of items per line per
   * screen format, specified small and medium up percentage settings and whether
   * or not it is permitted for the resulting percentage to enable a row with a
   * single item to be rendered.
   * Enabling the overriding the oj-list-view card layout default width with one
   * better suited to the screen size and additional requirements.
   *
   * @param {number} itemCount the number of items to be displayed
   * @param {object} responsive the JET responsive object
   * @param {number} maxItemsPerLineXl the maximum number of items to render on one line for XL format
   * @param {number} maxItemsPerLineLg the maximum number of items to render on one line for LG format
   * @param {number} maxItemsPerLineMd the maximum number of items to render on one line for MD format
   * @param {number} smWidthPercentage the width % to return for small form factor displayed items
   * @param {number} mdUpWidthMaxPercentage the maximum width % to use for medium and large form factor displayed items
   * @param {boolean} isSingleItemLinePermitted flags whether a row can contain a single item, if false an item it reduced from the maxItems
   * enabling the last row to contain more than one item
   * @return {string} the width percentage value or an empty string if no override is appropriate
   */
  AppModule.prototype.getFormatSpecificWidthPercentages = function(itemCount, responsive, maxItemsPerLineXl, maxItemsPerLineLg,
    maxItemsPerLineMd, smWidthPercentage, mdUpWidthMaxPercentage, isSingleItemLinePermitted) {
    return VisualNavigatorCommon.getFormatSpecificWidthPercentages(itemCount, responsive, maxItemsPerLineXl, maxItemsPerLineLg,
      maxItemsPerLineMd, smWidthPercentage, mdUpWidthMaxPercentage, isSingleItemLinePermitted);
  };

  /**
   * Validates whether the content type of a REST response is json or not.
   *
   * @param {Object} response The rest response.
   * @return {boolean} true if the response is a json response, otherwise false
   */
  AppModule.prototype.isJsonResponse = function(response) {
    return ApplicationCommon.isJsonResponse(response);
  };

  /**
   * Get the REST URL of the supplied endpoint id using VB's REST Helper.
   *
   * @param {string} endpointId id (service id/endpoint id) of the endpoint to get the URL for
   * @return {Promise} Promise that resolves to the endpoint's URL
   */
  AppModule.prototype.getRestURL = function(endpointId) {
    return Rest.get(endpointId).toUrl();
  };

  /**
   * Check whether the current chat status allows a chat to be initiated.
   *
   * @param {Object} chatStatus
   * @return {boolean} true if chat is available
   */
  AppModule.prototype.chatIsAvailable = function(chatPollingEnabled, chatStatus) {
    return !chatPollingEnabled || (chatStatus && chatStatus.availableAgentSessions > 0 && !chatStatus.outsideOperatingHours);
  };

  /**
   * Returns a date string in ISO format based on the dateKey passed in.
   * Options for dateKey:
   * 'today', which will return a string like: 2021-01-28T18:30:00.000Z
   *
   * @param {string} dateKey date needed in ISO format e.g. today
   * @return {string} date in ISO format
   */
  AppModule.prototype.getDateInIso = function(dateKey) {
    return ApplicationCommon.getDateInIso(dateKey);
  };

  /**
   * Returns a sorted set of items based on the sortToken and items passed in.
   * Options for sortToken:
   * 'workOrderRescheduleSlots' : handles item objects with date and time slots
   * where time slots are not from morning to evening like All-day, 08-10, 10-12, 13-15, 15-17
   * which will return sorted date object like [{'TimeSlotDate': '2021-01-29',TimeSlot': '10-12'},{'TimeSlotDate': '2021-01-29',TimeSlot': '13-15'}]
   *
   * @param {string} sortToken token for the items passed in the function e.g. workOrderRescheduleSlots
   * @param {Object} items data to be sorted
   * @return {Object} sorted data
   */
  AppModule.prototype.sortItems = function(sortToken, items) {
    return ApplicationCommon.sortItems(sortToken,items);
  };

  /**
   * Return maximum end date user can select to reschedule a work order
   *
   * @param {string} selectedDate  start date for the reschedulable work order
   * @return {Object} reschedulable end date for work order capacities list
   */
  AppModule.prototype.getMaxRescheduleDate = function(selectedDate) {
    return ApplicationCommon.getMaxRescheduleDate(selectedDate);
  };

  return AppModule;
});
