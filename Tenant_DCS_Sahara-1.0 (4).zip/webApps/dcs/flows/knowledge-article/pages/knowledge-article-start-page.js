define([
  'oj-odcs/knowledge-common/KnowledgeCommon',
  'ojs/ojbinddom'
], function(
  KnowledgeCommon
) {
  'use strict';

  var PageModule = function PageModule() {};

  return PageModule;
});