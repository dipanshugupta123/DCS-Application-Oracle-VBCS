define([], function() {
  'use strict';

  var PageModule = function PageModule() {};
  
  /**
   * Return whether save should be disabled for the current state.
   * 
   * @param {Object} page $page
   * @return {boolean} true if save should be disabled; false otherwise
   */  
  PageModule.prototype.isSaveDisabled = function(page) {
    return page.variables.myProfileWorkInProgress ||
           page.variables.myProfilePersonalInfoValidator != 'valid' || 
           page.variables.myProfileContactInfoValidator != 'valid';
  };
  
  /**
   * Return whether an address attribute from the addressFormatLayout should be rendered or not.
   * current attribute from the format layout
   * @param {Array} addressFields Array of enabled address fields 
   * @return {boolean} 
   * @param {String} attributeName 
   */
  PageModule.prototype.checkAttributeList = function(attributeName, addressFields) {
    return addressFields.includes(attributeName);
  };
  
  /**
   * Finds the name of a country in an array of country records using a territory code key.
   * 
   * @param {type} key The key to the lov lookup
   * @param {type} countriesLOV The LOV array of Country code - Territory name pairs
   * 
   * @return {String} Country name
   */
  PageModule.prototype.getCountryName = function(key,countriesLOV) {
    if (countriesLOV) {
      var res, record;
      for (var i = 0; i < countriesLOV.length; i++) {
        record = countriesLOV[i];
        if (record.TerritoryCode === key) {
          res = record;
          break;
        }
      }
      if (res) {
        return res.TerritoryShortName;
      }
    }
    return key;
  };
  
  /**
   * Sorts the countryList array by territory name
   * 
   * @param {Array} countriesLOV The LOV array of Country code - Territory name pairs
   * 
   * @return {Array} countrieLOV sorted by territory name
   */
  PageModule.prototype.sortCountryList = function(countriesLOV){
    countriesLOV.sort(function(a,b){
        return ((a.TerritoryShortName > b.TerritoryShortName) ? 1 : -1);
    });
    return countriesLOV;
  };

  return PageModule;
});