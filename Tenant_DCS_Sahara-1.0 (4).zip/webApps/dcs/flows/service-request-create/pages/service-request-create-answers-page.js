define(['ojs/ojcore', 'ojs/ojoffcanvas', 'ojs/ojbinddom'], function(oj) {
  'use strict';

  var PageModule = function PageModule() {};
  
  PageModule.prototype.showDrawer = function(drawerSelector, contentSelector) {
    oj.OffcanvasUtils.open({
      "selector": drawerSelector,
      "content": contentSelector,
      "modality": "modal",
      "displayMode": "overlay"
    });
  };

  PageModule.prototype.closeDrawer = function(drawerSelector) {
    oj.OffcanvasUtils.close({
      "selector": drawerSelector
    });
  };

  return PageModule;
});
