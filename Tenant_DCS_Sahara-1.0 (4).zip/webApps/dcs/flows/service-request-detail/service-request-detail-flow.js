define(['jquery'], function($) {
  'use strict';

  var FlowModule = function FlowModule() {};

  FlowModule.prototype.formatDate = function(dateStr) {
    var d = new Date(dateStr);
    return $.format.date(new Date(), 'yyyy/MM/dd HH:mm:ss');
  };

  return FlowModule;
});