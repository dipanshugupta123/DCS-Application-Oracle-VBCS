define(['ojs/ojfilepicker'], function() {
  'use strict';

  var PageModule = function PageModule() {
    /**
     * Compare two objects properties, if the same return true, otherwise false.
     * 
     * @param {Object} objectA One of the two objects to examine
     * @param {Object} objectB The other object to examine
     * @param {Array} propertiesToCheck A strng array of the properties to check 
     * @return {boolean} true if objects match, otherwise false.
     */
    PageModule.prototype.areObjectsEqual = function(objectA, objectB,
      propertiesToCheck) {
      var result = true;

      for (var i = 0; i < propertiesToCheck.length; i++) {
        var name = propertiesToCheck[i];
        if (objectA[name] !== objectB[name]) {
          result = false;
        }

        if (!result) {
          // Pop out of the for loop now a false result has been logged
          break;
        }
      }

      return result;
    };

    /**
     * Returns error message to be displayed based on the HTTP status code.
     * Called after a REST endpoint call fails
     * 
     * @param {number} statusCode HTTP status code from the REST payload 
     * 
     * @return {String} Message ID of the error messsage to be displayed as notification
     * 
     */
    PageModule.prototype.getErrorMessage = function(statusCode) {
      var messageId;
      if (statusCode === 404) {
        messageId = "serviceRequestDetail_serviceRequestNotFound";
      } else {
        messageId = "common_couldNotLoadDataMsg";
      }

      return messageId;
    };

  };

  return PageModule;
});