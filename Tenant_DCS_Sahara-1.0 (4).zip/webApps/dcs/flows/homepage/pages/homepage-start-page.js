define([
  'oj-odcs/knowledge-common/KnowledgeCommon'
], function(
  KnowledgeCommon
) {
  'use strict';

  var PageModule = function PageModule() {
  };

  /**
   * This method create referenceKey for category/product from response.
   * 
   * @param {type} response
   * @param {type} childKey referenceKey of child
   * @param {type} type category or product
   * @return referenceKey
   */
  PageModule.prototype.getReferenceKey = function(response, childKey, type) {
    return KnowledgeCommon.getReferenceKey(response, childKey, type);
  };

  return PageModule;
});
