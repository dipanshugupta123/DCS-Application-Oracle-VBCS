define([
  'ojs/ojhtmlutils'
], function(
  HtmlUtils
) {
  'use strict';
  var PageModule = function PageModule() {};

  /**
   * Returns the Bind Dom Config used to enable templating
   * of the knowledge facet tree view
   * 
   * @param {Object} viewElement The unique id to be used in the stamped out template
   * @param {String} id The unique id to be used in the stamped out template
   * @param {Object} application The application context
   * @param {Object} page The page context
   * @return {Object} The dom binding config
   */
  PageModule.prototype.getBindDomConfig = function(viewElement, id, application, page) {
    return {
      view: HtmlUtils.getTemplateContent(viewElement),
      data: {
        facetTreeInstanceId: id,
        $application: application,
        $page: page,
        $variables: page.variables
      }
    };
  };

  return PageModule;
});